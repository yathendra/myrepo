#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

#  list the components enabled
printf "\n***********************************************************"
printf "\n        COMPONENTS ENABLED FOR THE DEPLOYMENT "
printf "\n***********************************************************"
printf "\nFollowing are the Mobile Foundation components enabled."

[ "${mfpserver_enabled}" == "true" ] && printf " \n >    Mobile Foundation Server"
[ "${mfppush_enabled}" == "true" ] && printf " \n >    Push"
[ "${mfpliveupdate_enabled}" == "true" ] && printf " \n >    LiveUpdate"
[ "${mfpanalytics_recvr_enabled}" == "true" ] && printf " \n >    Analytics Receiver"
[ "${mfpanalytics_enabled}" == "true" ] && printf " \n >    Mobile Foundation Analytics"
[ "${mfpappcenter_enabled}" == "true" ] && printf " \n >    Application Center\n"
echo ""

if [ "${debug_enabled}" == "true" ]
then
    printf "\n***********************************************************"
    printf "\n       OPERATORS AUTO-ENABLED FOR THE DEPLOYMENT "
    printf "\n***********************************************************"
    if [ "${mfpserver_enabled}" == "true" ] || [ "${mfpappcenter_enabled}" == "true" ] 
    then
        [ "${db_host}" == "" ] && printf " \n >    DB2 Operator"
    fi
    [ "${mfpanalytics_enabled}" == "true" ] && printf " \n >    Elasticsearch Operator"
    printf " \n >    MF Operator"
    echo 
fi

printf "\n***********************************************************"