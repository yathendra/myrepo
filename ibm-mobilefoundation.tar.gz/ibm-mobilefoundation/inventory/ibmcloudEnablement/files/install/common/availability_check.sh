#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

echo 
echo "Check to see if the deployed components via the custom resource are available. "
echo

# print the readiness check return value
printReturnMsg() {
	RC=$1
	COMPONENT=$2
	if [ $RC -ne 0 ]; then
		printf "\n$2 readiness check failed."
		exit $RC
	fi
}

#
#  if analytics receiver is enabled without enabling analytics
#  disable the analytics receiver to prevent from unnecessary deployment
#  of the receiver component
#
if [ "${mfpanalytics_recvr_enabled}" == "true" ] && [ "${mfpanalytics_enabled}" == "false" ]
then
	_GEN_RECVR_ENABLE=false
else
	_GEN_RECVR_ENABLE=${mfpanalytics_recvr_enabled}
fi

checkMFReadiness()
{

	if [ "${mfpserver_enabled}" == "true" ]; then
		printf "\n *********** CHECK LIVELINESS & READINESS OF MOBILE FOUNDATION SERVER ************* "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_SYSGEN_MF_NAMESPACE} helm.sh/chart=ibm-mobilefoundation-prod-${_GEN_IMG_TAG},component=server ui
		RC=$?
		printReturnMsg $RC "Mobile Foundation Server"
	fi

	if [ "${mfppush_enabled}" == "true" ]; then
		printf "\n ************ CHECK LIVELINESS & READINESS OF MOBILE FOUNDATION PUSH ************** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_SYSGEN_MF_NAMESPACE} helm.sh/chart=ibm-mobilefoundation-prod-${_GEN_IMG_TAG},component=push ui
		RC=$?
		printReturnMsg $RC "Mobile Foundation Push"
	fi

	if [ "${mfpliveupdate_enabled}" == "true" ]; then
		printf "\n ********* CHECK LIVELINESS & READINESS OF MOBILE FOUNDATION LIVEUPDATE *********** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_SYSGEN_MF_NAMESPACE} helm.sh/chart=ibm-mobilefoundation-prod-${_GEN_IMG_TAG},component=liveupdate ui
		RC=$?
		printReturnMsg $RC "Mobile Foundation Liveupdate"
	fi

	if [ "${_GEN_RECVR_ENABLE}" == "true" ]; then
		printf "\n ****** CHECK LIVELINESS & READINESS OF MOBILE FOUNDATION ANALYTICS RECEIVER ****** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_SYSGEN_MF_NAMESPACE} helm.sh/chart=ibm-mobilefoundation-prod-${_GEN_IMG_TAG},component=analytics-recvr ui
		RC=$?
		printReturnMsg $RC "Mobile Foundation Analytics Receiver"
	fi

	if [ "${mfpanalytics_enabled}" == "true" ]; then
		printf "\n *********** CHECK LIVELINESS & READINESS OF MOBILE FOUNDATION ANALYTICS ********** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_SYSGEN_MF_NAMESPACE} helm.sh/chart=ibm-mobilefoundation-prod-${_GEN_IMG_TAG},component=analytics ui
		RC=$?
		printReturnMsg $RC "Mobile Foundation Analytics Service"
	fi

	if [ "${mfpappcenter_enabled}" == "true" ]; then
		printf "\n ****** CHECK LIVELINESS & READINESS OF MOBILE FOUNDATION APPLICATION CENTER ****** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_SYSGEN_MF_NAMESPACE} helm.sh/chart=ibm-mobilefoundation-prod-${_GEN_IMG_TAG},component=appcenter ui
		RC=$?
		printReturnMsg $RC appcenter
	fi

}

checkDB2Readiness()
{	
	if [ "${db_host}" == "" ]; then
		printf "\n *******************CHECK LIVELINESS & READINESS OF IBM DB2-etcd ****************** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_GEN_DB2_NAMESPACE} chart=ibm-db2-prod,component=etcd db2 60
		RC=$?
		printReturnMsg $RC db2-etcd

		printf "\n ****************** CHECK LIVELINESS & READINESS OF IBM DB2-tools ***************** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_GEN_DB2_NAMESPACE} chart=ibm-db2-prod,component=db2oltp,type=tools db2 60
		RC=$?
		printReturnMsg $RC db2u-tools

		printf "\n ***************** CHECK LIVELINESS & READINESS OF IBM DB2-primary **************** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_GEN_DB2_NAMESPACE} chart=ibm-db2-prod,statefulset.kubernetes.io/pod-name=db2-primary-ibm-db2u-db2u-0,type=engine db2 120
		RC=$?
		printReturnMsg $RC db2-primary-component	
	fi

}

checkESReadiness()
{

	if [ "${mfpanalytics_enabled}" == "true" ]; then
		printf "\n ************** CHECK LIVELINESS & READINESS OF ELASTICSEARCH CLIENT ************** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_GEN_ES_NAMESPACE} helm.sh/chart=ibm-es-prod-${_GEN_IMG_TAG},esnode=client backend
		RC=$?
		printReturnMsg $RC Elasticsearch-client

		printf "\n ************** CHECK LIVELINESS & READINESS OF ELASTICSEARCH MASTER ************** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_GEN_ES_NAMESPACE} helm.sh/chart=ibm-es-prod-${_GEN_IMG_TAG},esnode=master backend
		RC=$?
		printReturnMsg $RC Elasticsearch-master

		printf "\n *********** CHECK LIVELINESS & READINESS OF ELASTICSEARCH DATA SERVICE *********** "
		${CASE_FILES_DIR}/install/utils/check_pods_ready.sh ${_GEN_ES_NAMESPACE} helm.sh/chart=ibm-es-prod-${_GEN_IMG_TAG},esnode=data backend
		RC=$?
		printReturnMsg $RC Elasticsearch-data
	fi
}

#
# main
#

COMPONENT_NAME=$1

if [ "$COMPONENT_NAME" == "es" ]
then
	checkESReadiness $COMPONENT_NAME
fi

if [ "$COMPONENT_NAME" == "db2" ]
then
	checkDB2Readiness $COMPONENT_NAME
fi

if [ "$COMPONENT_NAME" == "mf" ]
then
	checkMFReadiness $COMPONENT_NAME
fi
