#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

printf "\n***********************************************************"
printf "\n                MOBILEFOUNDATION ROUTES                 "
printf "\n***********************************************************"

printf "\nFollowing are routes of deployed Mobile Foundation components.\n"

if [ "${mfpserver_enabled}" == "true" ]; then
	printf "\n\t\t\tMOBILE FOUNDATION SERVER CONSOLE \n\n"
	ROUTE=$(oc get route -o jsonpath='{range .items[*]}{@.spec.host}{@.spec.path}{"\n"}{end}' | grep 'mfpconsole')
	echo "http://${ROUTE}"
	echo "https://${ROUTE}"
fi

if [ "${mfpanalytics_enabled}" == "true" ]; then
	printf "\n\t\t\tMOBILE FOUNDATION ANALYTICS CONSOLE \n\n"
	ROUTE=$(oc get route -o jsonpath='{range .items[*]}{@.spec.host}{@.spec.path}{"\n"}{end}' | grep 'analytics' | grep -v 'service' | grep -v 'receiver')
	echo "http://${ROUTE}"
	echo "https://${ROUTE}"
fi

if [ "${mfpappcenter_enabled}" == "true" ]; then
	printf "\n\t\t\tMOBILE FOUNDATION APPCENTER CONSOLE \n\n"
	ROUTE=$(oc get route -o jsonpath='{range .items[*]}{@.spec.host}{@.spec.path}{"\n"}{end}' | grep 'appcenterconsole')
	echo "http://${ROUTE}"
	echo "https://${ROUTE}"
fi

printf "\n***********************************************************\n\n"
