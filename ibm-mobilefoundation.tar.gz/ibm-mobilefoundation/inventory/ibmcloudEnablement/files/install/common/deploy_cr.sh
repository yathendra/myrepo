#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

OPERATOR_NAME=$1
DEPLOY_NAMESPACE=$2

printf "\n***********************************************************"
printf "\n      Deploying the ${OPERATOR_NAME} custom resource"
printf "\n***********************************************************"

CR_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/crds/charts_v1_${OPERATOR_NAME}operator_cr.yaml"

# Create/Switch Project for 
${CASE_FILES_DIR}/install/utils/create_project.sh ${DEPLOY_NAMESPACE} ${OPERATOR_NAME}

#  Create the CR (deploy MF)
oc apply --namespace ${DEPLOY_NAMESPACE} -f ${CR_YAML}
RC=$?
if [ $RC -ne 0 ]; then
    printf "\n\tFailed to apply custom CR for the component - ${OPERATOR_NAME}."
    exit $RC
fi

echo ${DEPLOY_NAMESPACE} > "${CASE_FILES_DIR}/${OPERATOR_NAME}.txt"