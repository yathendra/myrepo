#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

echo
echo "Starting mf_preinstall ..."
echo 

# Create/Switch Project for ES
${CASE_FILES_DIR}/install/utils/create_project.sh ${_SYSGEN_MF_NAMESPACE} mf

_GEN_MF_IMG_PULLSECRET=mf-image-docker-pull

#  create pull secret
printf "\nCreating image pull secret ($_GEN_MF_IMG_PULLSECRET) for Mobile Foundation ..."
oc create secret docker-registry ${_GEN_MF_IMG_PULLSECRET} -n ${_SYSGEN_MF_NAMESPACE} --docker-server=${_SYSGEN_DOCKER_REGISTRY} --docker-username=${_SYSGEN_DOCKER_REGISTRY_USER} --docker-password=${_SYSGEN_DOCKER_REGISTRY_PASSWORD}
oc secrets -n ${_SYSGEN_MF_NAMESPACE} link default ${_GEN_MF_IMG_PULLSECRET} --for=pull

sed -i "s|_IMG_TAG_|${_GEN_IMG_TAG}|g" ${CASE_FILES_DIR}/components/mf/deploy/crds/charts_v1_mfoperator_crd.yaml
sed -i "s|_IMG_TAG_|${_GEN_IMG_TAG}|g" ${CASE_FILES_DIR}/components/mf/deploy/role.yaml
sed -i "s|_IMG_TAG_|${_GEN_IMG_TAG}|g" ${CASE_FILES_DIR}/components/mf/deploy/role_binding.yaml
sed -i "s|_IMG_TAG_|${_GEN_IMG_TAG}|g" ${CASE_FILES_DIR}/components/mf/deploy/scc.yaml
sed -i "s|_MF_NAMESPACE_|${_SYSGEN_MF_NAMESPACE}|g" ${CASE_FILES_DIR}/components/mf/deploy/role_binding.yaml


# Attempt to check if CRD exists
oc get crds mfoperators.mf.ibm.com  > /dev/null 2>&1
RC=$?

if [ $RC -ne 0 ]
then

    # create CRD
    oc create --namespace ${_SYSGEN_MF_NAMESPACE} -f ${CASE_FILES_DIR}/components/mf/deploy/crds/charts_v1_mfoperator_crd.yaml

    # create role
    oc create --namespace ${_SYSGEN_MF_NAMESPACE} -f ${CASE_FILES_DIR}/components/mf/deploy/role.yaml

    # create role-binding
    oc create --namespace ${_SYSGEN_MF_NAMESPACE} -f ${CASE_FILES_DIR}/components/mf/deploy/role_binding.yaml

    # create SCC
    oc create --namespace ${_SYSGEN_MF_NAMESPACE} -f ${CASE_FILES_DIR}/components/mf/deploy/scc.yaml

fi

# Create/Switch Project back to MF namespace
${CASE_FILES_DIR}/install/utils/create_project.sh ${_SYSGEN_MF_NAMESPACE} mf

echo "MobileFoundation preinstall completed."
echo