#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

echo
echo "Test Mobile Foundation DB connection ..."
echo 

DB_TYPE=$1

# Create/Switch Project for DB2
${CASE_FILES_DIR}/install/utils/create_project.sh ${_SYSGEN_MF_NAMESPACE} mf

printf "\nDatabase Host for test connection = $_GEN_DB_HOSTNAME"
#echo "DB user id  = ${_GEN_DB_USERID}"
#echo "DB password = ${_GEN_DB_PASSWORD}"

printJobDebugMsg()
{
      printf "\n\tFollowing is the error while testing the DB connection.\n"
      
      oc -n "${_SYSGEN_MF_NAMESPACE}" logs -f mftestdb

      printf "\n\n\n"
      printf "\n\tRun the following commands to examine the status of the job for more details:"
      printf "\n\toc -n \"${_SYSGEN_MF_NAMESPACE}\" describe pod mftestdb"
      printf "\n\toc -n \"${_SYSGEN_MF_NAMESPACE}\" logs -f mftestdb"
      echo
      printf "\n\tOnce the problem is resolved, You can redo the install again."
}

# Construct JDBC URL
SET_DB_TYPE=$(echo $DB_TYPE| tr '[:lower:]' '[:upper:]')

case $SET_DB_TYPE in
  "DB2") 
        printf "\nDB_TYPE set is DB2" ;
        JDBC_URL="jdbc:db2://${_GEN_DB_HOSTNAME}:${_GEN_DB_PORT}/${_GEN_DB_NAME}"; ;;
  "ORACLE") 
        printf "\n\tDB_TYPE is set to Oracle";
        echo "Only IBM DB2 is supported at this moment." ;;
  "MYSQL") 
        printf "\n\tDB_TYPE is set to MySQL";
        echo "Only IBM DB2 is supported at this moment." ;;
  *) 
        echo "Invalid / No input for DB_TYPE. Setting to DB2" ;
        DB_TYPE=DB2;
        JDBC_URL="jdbc:db2://${_GEN_DB_HOSTNAME}:${_GEN_DB_PORT}/${_GEN_DB_NAME}" ;;
esac

# check if the secret exists

printf "\nCreating a test connection pod within the namespace - ${_SYSGEN_MF_NAMESPACE} ..."

oc run mftestdb --image=${_SYSGEN_DOCKER_REGISTRY}/cp/mfpf-dbinit:${_GEN_IMG_TAG} \
            --env="POD_NAMESPACE=${_SYSGEN_MF_NAMESPACE}" \
            --overrides='{ "apiVersion": "v1", "spec": { "imagePullSecrets": [{"name": "mf-image-docker-pull"}] } }' \
            --restart=Never \
            --command -- java -Dij.driver=com.ibm.db2.jcc.DB2Driver \
             -Dij.dburl=${JDBC_URL} -Dij.user=${_GEN_DB_USERID// } \
             -Dij.password=${_GEN_DB_PASSWORD// } \
             -cp /opt/ibm/MobileFirst/mfpf-libs/mfp-ant-deployer.jar:/opt/ibm/MobileFirst/dbdrivers/db2jcc4.jar \
              com.ibm.worklight.config.helper.database.CheckDatabaseExistence db2
RC=$?

if [ $RC -ne 0 ]; then
    printf "\n\tMobile Foundation Database Test connection failure."  
    exit $RC
else
      wait_period=0
      while true
      do
            wait_period=$(($wait_period+5))
            if [ $wait_period -gt 60 ];then
                  POD_STATUS_MSG=$(oc get pod mftestdb --output="jsonpath={.status.phase}")

                  if [ "$POD_STATUS_MSG" = "Succeeded" ]
                  then
                        oc logs mftestdb | grep " exists."
                        if [ $? -eq 0 ]
                        then
                              printf "\nDatabase test connection successful."
                              sleep 4
                              printf "\nCleaning up the DB test connection pod ..."
                              oc delete pod mftestdb -n ${_SYSGEN_MF_NAMESPACE}
                        else
                              printf "\nDatabase test connection failed. Ensure Database details are set correctly."
                              #oc delete --ignore-not-found pod mftestdb -n ${NAMESPACE}
                              printJobDebugMsg
                              
                              exit 1
                        fi
                        break;
                  elif [ "$POD_STATUS_MSG" = "Failed" ]
                  then
                        printf "\nDatabase test connection job failed. Ensure Database details are set correctly. "
                        # oc delete --ignore-not-found pod mftestdb -n ${NAMESPACE}
                        printJobDebugMsg
                        
                        exit 1
                  fi
            fi
      done
fi

echo "Test DB connection completed."
