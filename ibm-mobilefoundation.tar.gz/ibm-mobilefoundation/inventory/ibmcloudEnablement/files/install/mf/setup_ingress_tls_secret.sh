#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

echo
printf "\n***********************************************************"
printf "\n               SETTING UP INGRESS SECRET"
printf "\n***********************************************************"
echo

if [ "${ingress_secret}" == "" ]
then 
    oc get secret ${INGRESS_SECRET_NAME} -n default  > /dev/null 2>&1
    RC1=$?

    oc get secret ${INGRESS_SECRET_NAME} -n openshift-ingress  > /dev/null 2>&1
    RC2=$?
    
    if [ $RC1 -eq 0 ]; then
        oc get secret ${INGRESS_SECRET_NAME} -n default --export -o yaml | oc apply --namespace=${_SYSGEN_MF_NAMESPACE} -f -
    fi

    if [ $RC2 -eq 0 ]; then
        oc get secret ${INGRESS_SECRET_NAME} -n openshift-ingress --export -o yaml | oc apply --namespace=${_SYSGEN_MF_NAMESPACE} -f -
    fi

    oc get secret ${INGRESS_SECRET_NAME} -n ${_SYSGEN_MF_NAMESPACE} >/dev/null 2>&1
    TLS_SECRET_EXISTS=$?

    if [ $TLS_SECRET_EXISTS -ne 0 ]
    then
        printf "\nIngress secret name (${INGRESS_SECRET_NAME}) doesn't exists."
        printf "\nProceeding without ingress secret name ..."
    else
        printf "\nIngress secret name successfully exported to the namespace - ${_SYSGEN_MF_NAMESPACE}."
    fi

else
    printf "\n\tUsing the custom ingress secret name : ${ingress_secret} "
    oc get secret ${ingress_secret} -n ${_SYSGEN_MF_NAMESPACE} >/dev/null 2>&1
    TLS_SECRET_EXISTS=$?

    if [ $TLS_SECRET_EXISTS -ne 0 ]
    then
        printf "\nIngress secret(${ingress_secret}) doesn't exists. "
        printf "\nEnsure the secret(${ingress_secret}) is created within the namespace \"${_SYSGEN_MF_NAMESPACE}\"" 
        printf "\nProceeding without ingress secret name ..."
    fi
fi

echo