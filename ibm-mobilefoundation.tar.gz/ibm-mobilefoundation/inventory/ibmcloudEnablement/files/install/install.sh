#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

printf "\nInstall procedure starting ...\n"

export CASE_FILES_DIR="./ibm-mobilefoundation/inventory/ibmcloudEnablement/files"

#  Following are to be used from the builtin ENV variables
export _SYSGEN_MF_NAMESPACE=${JOB_NAMESPACE}
export _GEN_DB2_NAMESPACE=${db_namespace:-mfdb}
export _GEN_ES_NAMESPACE=${elasticsearch_namespace:-mfes}

export _SYSGEN_DOCKER_REGISTRY=${DOCKER_REGISTRY}
export _SYSGEN_DOCKER_REGISTRY="cp.icr.io"
export _SYSGEN_DOCKER_REGISTRY_USER=${DOCKER_REGISTRY_USER}
export _SYSGEN_DOCKER_REGISTRY_PASSWORD=${DOCKER_REGISTRY_PASS}

export _SYSGEN_DOCKER_REGISTRY="cp.stg.icr.io"
export _SYSGEN_DOCKER_REGISTRY_USER="iamapikey"
export _SYSGEN_DOCKER_REGISTRY_PASSWORD="lmTwt2gWsxJk25XAFATqGqkdWxWWOdsSfJhYL7Gomslo"

echo "******************remove post testing**************************"
echo "System set variables ..."
echo "DOCKER_REGISTRY=${DOCKER_REGISTRY}"
echo "DOCKER_REGISTRY_USER=$DOCKER_REGISTRY_USER"
echo "DOCKER_REGISTRY_PASS=$DOCKER_REGISTRY_PASS"
echo "ENVIRONMENT=$ENVIRONMENT"
echo "********************************************"

echo "For only test - set variables ..."
echo "_SYSGEN_DOCKER_REGISTRY_USER=$_SYSGEN_DOCKER_REGISTRY_USER"
echo "_SYSGEN_DOCKER_REGISTRY_PASSWORD=$_SYSGEN_DOCKER_REGISTRY_PASSWORD"
echo "******************remove post testing**************************"


export _GEN_SERVER_DB_SCHEMA=${mfpserver_db_schema:-MFPDATA}
export _GEN_LU_DB_SCHEMA=${mfpliveupdate_db_schema:-MFPLIVUPD}
export _GEN_AC_DB_SCHEMA=${mfpappcenter_db_schema:-APPCNTR}

export _GEN_DB_PORT=${db_port:-50000}
export _GEN_DB_NAME=${db_name:-BLUDB}
export _GEN_DB_USERID=${db_userid:-db2inst1}
export _GEN_DB_PASSWORD=${db_password:-db2inst1}

#  Mobile Foundation Image tag
export _GEN_IMG_TAG=8.1.0

exitDeploymentOnFailure()
{
	RC=$1
	MSG="$2"
	printf "\n\t$MSG"
	if [ $RC -ne 0 ]; then
		printf "\n\tExiting ..."
		exit $RC
	fi
}

findExistingMFDeployments()
{

	echo 
	echo "Locating the existing MobileFoundation deployments with the cluster ..."
	echo "Please wait."
	echo 
	
	ALL_PROJECTS=$(oc get projects -o jsonpath='{range .items[*]} {@.metadata.name}')

	for PROJECT_ENTRY in $ALL_PROJECTS; do
		
		if [[ "${PROJECT_ENTRY}" == "openshift"* ]] || [[ "${PROJECT_ENTRY}" == "kube-"* ]]
		then 
			continue
		fi

		CREATED_BY=$(oc get namespace $PROJECT_ENTRY -o jsonpath='{.metadata.annotations.ibm\.com/created-by}')

		if [ "$CREATED_BY" == "MobileFoundation-es" ]; then
			echo "Elasticsearch deployment found under namespace - ${PROJECT_ENTRY}"
			echo "$PROJECT_ENTRY" > ${CASE_FILES_DIR}/es.txt
		fi

		if [ "$CREATED_BY" == "MobileFoundation-db2" ]; then
		echo "DB2 deployment found under namespace - ${PROJECT_ENTRY}"
			echo "$PROJECT_ENTRY" > ${CASE_FILES_DIR}/db2.txt
		fi

	done
}

invokeESUninstallForUpdate()
{
	oc projects | grep ${ALREADY_DEPLOYED_ES_NAMESPACE} >/dev/null 2>&1
	if [ $? -eq 0 ]
	then
		# Undeploy the already installed ES
		echo "Elasticsearch deployment already exists in namespace - ${ALREADY_DEPLOYED_ES_NAMESPACE}."
		echo "New namespace entered to deploy the Elasticsearch is ${_GEN_ES_NAMESPACE}."
		echo 
		echo "Proceeding to undeploy the Elasticsearch installed under namespace - ${ALREADY_DEPLOYED_ES_NAMESPACE}."

		${CASE_FILES_DIR}/install/cleanup/pre_uninstall.sh es ${ALREADY_DEPLOYED_ES_NAMESPACE}

		# delete the ES project
		${CASE_FILES_DIR}/install/utils/delete_project.sh ${ALREADY_DEPLOYED_ES_NAMESPACE}
	fi
}

invokeDB2UninstallForUpdate()
{
	oc projects | grep ${ALREADY_DEPLOYED_DB2_NAMESPACE} >/dev/null 2>&1
	if [ $? -eq 0 ]
	then
		# Undeploy the already installed DB2
		echo "DB2 deployment already exists in namespace - ${ALREADY_DEPLOYED_DB2_NAMESPACE}."
		echo "New namespace entered to deploy the DB2 is ${_GEN_DB2_NAMESPACE}."
		echo 
		echo "Proceeding to undeploy the DB2 installed under namespace - ${ALREADY_DEPLOYED_DB2_NAMESPACE}."

		${CASE_FILES_DIR}/install/cleanup/pre_uninstall.sh db2 ${ALREADY_DEPLOYED_DB2_NAMESPACE}

		# delete the DB2 project
		${CASE_FILES_DIR}/install/utils/delete_project.sh ${ALREADY_DEPLOYED_DB2_NAMESPACE}
	fi
}

deletePreExistingES()
{
	ALREADY_DEPLOYED_ES_NAMESPACE=$(cat ${CASE_FILES_DIR}/es.txt)

	# completely uninstall ES when analytics is disabled
	if [ "${mfpfanalytics_enabled}" == "false" ] 
	then
		invokeESUninstallForUpdate
		return 0
	fi

	# Compare old namespace and new namespace for ES
	if [ "${ALREADY_DEPLOYED_ES_NAMESPACE}" != "${elasticsearch_namespace// }" ]
	then	
		if [ "${ALREADY_DEPLOYED_ES_NAMESPACE}" != "${_GEN_ES_NAMESPACE}" ]
		then
			invokeESUninstallForUpdate
		fi
	fi
}

deletePreExistingDB2()
{
	ALREADY_DEPLOYED_DB2_NAMESPACE=$(cat ${CASE_FILES_DIR}/db2.txt)

	# completely uninstall DB2 when analytics is disabled
	if [ "${mfpfserver_enabled}" == "false" ] && [ "${mfpfappcenter_enabled}" == "false" ]
	then
		invokeDB2UninstallForUpdate
		return 0
	fi
	
	# Compare old namespace and new namespace for DB2
	if [ "${ALREADY_DEPLOYED_DB2_NAMESPACE}" != "${db_namespace// }" ]
	then	
		if [ "${ALREADY_DEPLOYED_DB2_NAMESPACE}" != "${_GEN_DB2_NAMESPACE}" ]
		then
			invokeDB2UninstallForUpdate
		fi
	fi
}

# if db_host is set, assume user wants to deploy MF with external database
# then force the DB2_NAMESPACE to empty
if [ "${db_host// }" != "" ]
then
	_GEN_DB2_NAMESPACE=""
fi

#  Set image pull secret name
_GEN_MF_PULLSECRET=mf-image-docker-pull

#  list all the components enabled 
${CASE_FILES_DIR}/install/common/list_enabled_components.sh

# List all the user set deployment values
if [ "${debug_enabled}" == "true" ]
then
	${CASE_FILES_DIR}/install/common/list_all_deploymentValues.sh
fi

#  validate inputs
${CASE_FILES_DIR}/install/common/input_validations.sh
exitDeploymentOnFailure $?

# Setup TLS secret
${CASE_FILES_DIR}/install/mf/setup_ingress_tls_secret.sh

#  Generate DB secret
if [ "${mfpserver_enabled}" == "true" ] || [ "${mfpappcenter_enabled}" == "true" ]
then
	${CASE_FILES_DIR}/install/mf/generate_db_secrets.sh
	exitDeploymentOnFailure $?
fi

#  Create console login secret
${CASE_FILES_DIR}/install/common/generate_consolelogin_secrets.sh
exitDeploymentOnFailure $?

# Check for the pre-existing Mobile Foundation deployments (esp. DB2 & ES)
findExistingMFDeployments

if [ -f "${CASE_FILES_DIR}/db2.txt" ]
then
	deletePreExistingDB2
fi

#  deploy db2
if [ "${mfpserver_enabled}" == "true" ] || [ "${mfpappcenter_enabled}" == "true" ]
then
	if [ "${db_host// }" == "" ] && [ "${_GEN_DB2_NAMESPACE}" != "" ]
	then
		echo
		printf "\n***********************************************************"
		printf "\n               DEPLOY DB2 COMPONENTS"
		printf "\n***********************************************************"
		echo

		# Attempt to check if CRD exists
		oc get crds db2operators.db2.ibm.com -n ${_GEN_DB2_NAMESPACE} > /dev/null 2>&1
		DB2RC=$?

		if [ $DB2RC -ne 0 ]
		then
			#  deploy db2 operator
			${CASE_FILES_DIR}/install/db2/db2_preinstall.sh
			${CASE_FILES_DIR}/install/common/deploy_operator.sh db2 ${_GEN_DB2_NAMESPACE} db2-image-docker-pull
		else
			printf "\n User running the update of the existing deployement."
		fi

		${CASE_FILES_DIR}/install/common/operators_availability_check.sh db2 ${_GEN_DB2_NAMESPACE} "DB2 Operator"
		exitDeploymentOnFailure $?

		echo 
		printf "\n***********************************************************"
		printf "\n         ADD DEPLOYMENT VALUES FOR IBM DB2"
		printf "\n***********************************************************"
		echo
		#  Adding deployment values for DB2
		${CASE_FILES_DIR}/install/common/add_deployment_values.sh db2
		
		if [ "${debug_enabled}" == "true" ]
		then
			printf "\n Below is the charts_v1_db2operator_cr.yaml for deployment.\n"
			printf "\n************************************************************************************************\n"
			cat "${CASE_FILES_DIR}/components/db2/deploy/crds/charts_v1_db2operator_cr.yaml"
			printf "\n***********************************************************************************************\n"
		fi

		# deploy db2 CR
		${CASE_FILES_DIR}/install/common/deploy_cr.sh db2 ${_GEN_DB2_NAMESPACE}
		exitDeploymentOnFailure $?

		echo 
		printf "\n***********************************************************"
		printf "\n          AVAILABILITY CHECK : IBM DB2 SERVICES"
		printf "\n***********************************************************"
		echo
		#  Check DB pod/services availability
		${CASE_FILES_DIR}/install/common/availability_check.sh db2

		DB2_RESTORE_JOB="db2-primary-ibm-db2u-db2u-restore-morph-job"

		for (( i=1; i<=50; i++ ))
		do
			printf "\n\tChecking if ${DB2_RESTORE_JOB} is Complete ... ($i/50)"
			oc wait --namespace ${_GEN_DB2_NAMESPACE} --for=condition=complete --timeout=10s job/${DB2_RESTORE_JOB} > /dev/null 2>&1
			if [ $? -eq 0 ]; then
				printf "\nJob - ${DB2_RESTORE_JOB} is completed."
				break;
			fi
		done
	fi
fi


if [ -f "${CASE_FILES_DIR}/es.txt" ]
then
	deletePreExistingES
fi

#  deploy es
if [ "${mfpanalytics_enabled}" == "true" ]
then

	echo 
	printf "\n***********************************************************"
	printf "\n           DEPLOY ELASTICSEARCH COMPONENTS"
	printf "\n***********************************************************"
	echo

		# Attempt to check if CRD exists
	oc get crds esoperators.es.ibm.com  -n ${_GEN_ES_NAMESPACE} > /dev/null 2>&1
	ESRC=$?

	if [ $ESRC -ne 0 ]
	then
		#  deploy es operator
		${CASE_FILES_DIR}/install/es/es_preinstall.sh
		${CASE_FILES_DIR}/install/common/deploy_operator.sh es ${_GEN_ES_NAMESPACE} es-image-docker-pull
	else
		printf "\n User running the update of the existing deployement."
	fi

	${CASE_FILES_DIR}/install/common/operators_availability_check.sh es ${_GEN_ES_NAMESPACE} "Elasticsearch Operator"
	exitDeploymentOnFailure $?

	echo 
	printf "\n***********************************************************"
	printf "\n        ADD DEPLOYMENT VALUES FOR ELASTICSEARCH"
	printf "\n***********************************************************"
	echo
	#  Adding deployment values for ES
	${CASE_FILES_DIR}/install/common/add_deployment_values.sh es

	if [ "${debug_enabled}" == "true" ]
	then
		printf "\n Below is the charts_v1_esoperator_cr.yaml for deployment.\n"
		printf "\n************************************************************************************************\n"
		cat "${CASE_FILES_DIR}/components/es/deploy/crds/charts_v1_esoperator_cr.yaml"
		printf "\n***********************************************************************************************\n"
	fi

	# deploy ES CR
	${CASE_FILES_DIR}/install/common/deploy_cr.sh es ${_GEN_ES_NAMESPACE}
	exitDeploymentOnFailure $?

	echo 
	printf "\n***********************************************************"
	printf "\n      AVAILABILITY CHECK : ELASTICSEARCH SERVICES"
	printf "\n***********************************************************"
	echo

	#  Check ES pod/services availability
	${CASE_FILES_DIR}/install/common/availability_check.sh es
	exitDeploymentOnFailure $?
fi

# Test DB Connection 
if [ "${mfpserver_enabled}" == "true" ] || [ "${mfpappcenter_enabled}" == "true" ] 
then
	if [ "${db_host}" == "" ]
	then
		printf "\nGetting DB Service hostname ..."
		# get db2 primary service host
		_GEN_DB_SRV_NAME=$(oc get svc -n "${_GEN_DB2_NAMESPACE}" -l app=db2-primary-ibm-db2u,chart=ibm-db2-prod,servicetype=mf-db2-primary -o json | jq .items[0].metadata.name | sed "s/\"//g")
		exitDeploymentOnFailure $? "Failed to get the DB2 Service name"

		export _GEN_DB_HOSTNAME="${_GEN_DB_SRV_NAME}.${_GEN_DB2_NAMESPACE}.svc"
	else
		export _GEN_DB_HOSTNAME=${db_host}
	fi

	#  check for db reachability/test connection
	${CASE_FILES_DIR}/install/mf/check_for_mf_database.sh "DB2"
	exitDeploymentOnFailure $?

fi

echo
printf "\n***********************************************************"
printf "\n         DEPLOY MOBILE FOUNDATION COMPONENTS"
printf "\n***********************************************************"
echo

# Attempt to check if CRD exists
oc get crds mfoperators.mf.ibm.com  -n ${_SYSGEN_MF_NAMESPACE} > /dev/null 2>&1
MFRC=$?

if [ $MFRC -ne 0 ]
then
	#  deploy mf operator
	${CASE_FILES_DIR}/install/mf/mf_preinstall.sh
	${CASE_FILES_DIR}/install/common/deploy_operator.sh mf ${_SYSGEN_MF_NAMESPACE} mf-image-docker-pull
else
	printf "\n User running the update of the existing deployement."
fi

${CASE_FILES_DIR}/install/common/operators_availability_check.sh mf ${_SYSGEN_MF_NAMESPACE} "Mobile Foundation Operator"
exitDeploymentOnFailure $?

echo 
printf "\n***********************************************************"
printf "\n          ADD DEPLOYMENT VALUES FOR ELASTICSEARCH"
printf "\n***********************************************************"
echo
#  Adding deployment values for MF
${CASE_FILES_DIR}/install/common/add_deployment_values.sh mf

if [ "${debug_enabled}" == "true" ]
then
	printf "\n Below is the charts_v1_mfoperator_cr.yaml for deployment.\n"
	printf "\n************************************************************************************************\n"
	cat "${CASE_FILES_DIR}/components/mf/deploy/crds/charts_v1_mfoperator_cr.yaml"
	printf "\n***********************************************************************************************\n"
fi

# deploy MF CR
${CASE_FILES_DIR}/install/common/deploy_cr.sh mf ${_SYSGEN_MF_NAMESPACE}
exitDeploymentOnFailure $?

echo 
printf "\n***********************************************************"
printf "\n      AVAILABILITY CHECK : MOBILEFOUNDATION SERVICES"
printf "\n***********************************************************"
echo
#  Check MF services availability
${CASE_FILES_DIR}/install/common/availability_check.sh mf
exitDeploymentOnFailure $?

#  Print routes
${CASE_FILES_DIR}/install/common/print_routes.sh