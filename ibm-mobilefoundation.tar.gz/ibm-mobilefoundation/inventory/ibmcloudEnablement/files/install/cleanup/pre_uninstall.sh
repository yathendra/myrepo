#!/bin/bash
# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

OPERATOR_NAME=$1
DEPLOYED_NAMESPACE=$2

CRD_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/crds/charts_v1_${OPERATOR_NAME}operator_crd.yaml"
CR_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/crds/charts_v1_${OPERATOR_NAME}operator_cr.yaml"
OPERATOR_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/operator.yaml"

if [ "${OPERATOR_NAME}" == "db2" ]
then
    SA_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/db2u-sa.yaml"
    ROLE_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/db2u-role.yaml"
    ROLE_BINDING_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/db2u-rolebinding.yaml"
    SCC_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/db2u-scc.yaml"
else
    SA_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/service_account.yaml"
    ROLE_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/role.yaml"
    ROLE_BINDING_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/role_binding.yaml"
    SCC_YAML="${CASE_FILES_DIR}/components/${OPERATOR_NAME}/deploy/scc.yaml"
fi

oc delete --namespace ${DEPLOYED_NAMESPACE} -f ${CR_YAML}
oc delete --namespace ${DEPLOYED_NAMESPACE} -f ${SA_YAML}
oc delete --namespace ${DEPLOYED_NAMESPACE} -f ${SCC_YAML}
oc delete --namespace ${DEPLOYED_NAMESPACE} -f ${OPERATOR_YAML}
oc delete --namespace ${DEPLOYED_NAMESPACE} -f ${ROLE_YAML}
oc delete --namespace ${DEPLOYED_NAMESPACE} -f ${ROLE_BINDING_YAML}
oc delete --namespace ${DEPLOYED_NAMESPACE} -f ${CRD_YAML}

oc delete --ignore-not-found --namespace ${DEPLOYED_NAMESPACE} secret ${OPERATOR_NAME}-image-docker-pull

if [ "${OPERATOR_NAME}" == "mf" ]
then
    oc delete --ignore-not-found --namespace ${DEPLOYED_NAMESPACE} secret mobilefoundation-db-secret
    oc delete --ignore-not-found --namespace ${DEPLOYED_NAMESPACE} secret serverlogin
    oc delete --ignore-not-found --namespace ${DEPLOYED_NAMESPACE} secret analyticslogin
    oc delete --ignore-not-found --namespace ${DEPLOYED_NAMESPACE} secret appcntrlogin
    oc delete --ignore-not-found --namespace ${DEPLOYED_NAMESPACE} secret mfpanalytics-recvrsecret 
    oc delete --ignore-not-found --namespace ${DEPLOYED_NAMESPACE} secret mfpliveupdate-clientsecret
fi

if [ "${OPERATOR_NAME}" == "db2" ]
then

    rm "${CASE_FILES_DIR}/db2.txt"  > /dev/null 2>&1

    # patching db2 deployment
    oc patch db2/db2-primary -p '{"metadata":{"finalizers":[]}}' --type=merge  > /dev/null 2>&1
else

    if [ "${OPERATOR_NAME}" == "es" ]
    then
        rm "${CASE_FILES_DIR}/es.txt"   > /dev/null 2>&1
    fi

    # patching es/mf deployment
    oc patch ${OPERATOR_NAME}operator.${OPERATOR_NAME}.ibm.com ${DEPLOYED_NAMESPACE} -p '{"metadata":{"finalizers":[]}}' --type=merge   > /dev/null 2>&1
fi